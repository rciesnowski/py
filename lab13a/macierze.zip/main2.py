import macierze

m1 = macierze.Macierz(3,2)
m2 = macierze.Macierz(4,5)

print(m1)
print(m2)
m1.sumaWierszy()
m2.sumaWierszy()